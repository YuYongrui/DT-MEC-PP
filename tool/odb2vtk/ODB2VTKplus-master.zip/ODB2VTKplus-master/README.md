# ODB2VTKplus test_version
This Python script is released with the paper: LIU Qing-bin, PAN Mao, LIU Jie, GUO Yan-jun, ZHANG Xiao-shuang, YAO Jian-peng, LI Fang-yu. ParaView Visualization and Virtual Reality of Output of Finite Element Analysis in Abaqus[J/OL]. Rock and Soil Mechanics,2019(12):1-9[2019-05-25]. https://doi.org/10.16285/j.rsm.2018.1794. Please cite it if the script is used in your reports/papers.

We suggest the samples from https://github.com/Liujie-SYSU/odb2vtk/tree/master/Samples to learn the script.

Note: Some modifications to script is necessary when handle different mission.
